# General tips

[01-cluster state](./docs/01-cluster-state-questions.md)
