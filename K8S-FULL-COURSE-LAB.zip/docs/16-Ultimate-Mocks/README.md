# CKA Ultimate Mocks

NOTE: CKA Ultimate Mocks is a separate course from the main CKA course, and as such requires a separate payment or is included in Pro subscription.

In this section, we will go through some of the most troublesome questions - these being the ones that get the most requests for help on our various forums.


* [Troubleshooting](./02-Troubleshooting/)
* [Storage](./04-Storage/)
* [Services/Networking](./05-Services-Networking/)
* [General](./09-general/)
