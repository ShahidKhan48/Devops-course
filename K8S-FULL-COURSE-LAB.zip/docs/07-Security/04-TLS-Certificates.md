# TLS Certificates Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/topic/tls-introduction/)
  
In this section, we will take a look at TLS certificates
- What are TLS certificates?
- How does kubernetes use certificates?
- How to generate them?
- How to configure them?
- How to view them?
- How to troubleshoot issues related to certificates
