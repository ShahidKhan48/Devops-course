# Certificate Health-Check Spreadsheet
  - Take me to [Spreadsheet](https://kodekloud.com/topic/certificate-health-check-spreadsheet/)
  
