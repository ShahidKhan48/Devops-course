# Storage Section Introduction

  - Take me to [Introduction](https://kodekloud.com/topic/storage-section-introduction/)

 In this section, we will take a look at **Storage**
 
 - Introduction of Docker Storage
 - Persistent Volume Claim
 - Persistent Volume
 - Storage Class