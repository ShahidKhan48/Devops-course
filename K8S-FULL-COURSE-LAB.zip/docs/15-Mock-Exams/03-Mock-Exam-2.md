# Mock Exam 2

  Level Up! 
  Take me to [Mock Exam 2](https://kodekloud.com/topic/mock-exam-2-3/)

  