# Mock Exam 3

  Wohooo! Level Up! 
  
  Take me to [Mock Exam 3](https://kodekloud.com/topic/mock-exam-3-2/)
