# Introduction - Kubeadm

Note that this section is for your own practice only. To our knowledge there has never been an exam question that requires you to install a cluster. Questions asking you to _upgrade an existing cluster_ are not uncommon!

  - Take me to [Introduction](https://kodekloud.com/topic/introduction-to-deployment-with-kubeadm/)

If you have an Apple M1 or M2 (Apple Silicon) machine, then please follow the separate instructions [here](../../apple-silicon/README.md).
