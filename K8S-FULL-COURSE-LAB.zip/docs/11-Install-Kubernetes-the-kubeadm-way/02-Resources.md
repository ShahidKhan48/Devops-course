# Resources

  - Take me to [Resources](https://kodekloud.com/topic/resources-2/)

If you have an Apple M1 or M2 (Apple Silicon) machine, then please follow the separate instructions [here](../../apple-silicon/README.md).
