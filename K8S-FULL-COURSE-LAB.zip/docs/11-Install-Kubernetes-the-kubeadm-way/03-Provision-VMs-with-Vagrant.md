# Provision VMs with Vagrant tool

  - Take me to [Lecture](https://kodekloud.com/topic/deploy-with-kubeadm-provision-vms-with-vagrant/)

If you want to build your own cluster, check these out. They are more up to date than the video currently :smile:

* [Kubeadm Clusters](../../kubeadm-clusters/)
* [Managed Clusters](../../managed-clusters/)

