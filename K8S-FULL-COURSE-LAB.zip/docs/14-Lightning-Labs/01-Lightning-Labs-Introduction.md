# Lightning Labs Introduction

  #### Welcome to the KodeKloud CKA Lightning Labs!
   
  - This section has been created to give you hands-on practice in solving questions of mixed difficulty in a short period of time.
   
  - This environment is only valid for 35 minutes. You have 5-8 questions to complete within this time.
   
  - You can toggle between the questions but make sure that that you click on `END EXAM` before the 35 minute mark. To pass, you need to secure 80%.
   
   Good Luck!!!
   
   Note: Answers for most questions should be available under the `/var/answers` directory on the master node.
   
   
  #### Disclaimer:
   
  - Please note that this exam is not a replica of the actual exam
  - Please note that the questions in these exams are not the same as in the actual exam
  - Please note that the interface is not the same as in the actual exam
  - Please note that the scoring system may not be the same as in the actual exam
  - Please note that the difficulty level may not be the same as in the actual exam
   
   
  - I want to understand what Lightning Lab is, [Let's Explore](https://kodekloud.com/topic/lightning-lab-introduction/)

