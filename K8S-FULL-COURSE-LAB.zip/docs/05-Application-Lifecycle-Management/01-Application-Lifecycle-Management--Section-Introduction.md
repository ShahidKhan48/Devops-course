# Application Lifecycle Management Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/topic/application-lifecycle-management-section-introduction/)
  
In this section, we will take a look at application lifecycle management
- Rolling Updates and Rollbacks in Deployments
- Configure Applications
- Scale Applications
- Self-Healing Application

