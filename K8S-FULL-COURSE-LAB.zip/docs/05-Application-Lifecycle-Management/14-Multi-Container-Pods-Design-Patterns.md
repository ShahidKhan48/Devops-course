# Multi-Container Pods Design Patterns
  - Take me to [Design Pattern page](https://kodekloud.com/topic/multi-container-pods-design-patterns/)
  
  ![dp](../../images/dp.PNG)
  
#### K8s Reference Docs
- https://kubernetes.io/blog/2015/06/the-distributed-system-toolkit-patterns/
