# Pre-requisite for JSON PATH

  - I want to know more about JSON PATH and its [Pre-requisite](https://kodekloud.com/topic/pre-requisites-json-path/)  

  