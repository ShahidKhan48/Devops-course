# Labs JSON PATH

  - I want to learn JSON, Take me to [JSON PATH](https://kodekloud.com/topic/labs-json-path-3/)

  