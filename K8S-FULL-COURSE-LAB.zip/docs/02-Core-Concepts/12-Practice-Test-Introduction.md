# Practice Test Introduction

In this section, we will take a look at practice test demo.
- Take me to [Video Tutorial](https://kodekloud.com/topic/practice-test-introduction-2/)

