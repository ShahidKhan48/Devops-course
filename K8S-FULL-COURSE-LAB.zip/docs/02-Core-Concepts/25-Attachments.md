# KodeKloud - CKA Course Documents
  - Take me to the [Presentation Deck - 1](https://kodekloud.com/topic/attachments/)
  - Take me to the [Presentation Deck - 2](https://kodekloud.com/topic/download-presentation-deck-for-this-section-1/)

