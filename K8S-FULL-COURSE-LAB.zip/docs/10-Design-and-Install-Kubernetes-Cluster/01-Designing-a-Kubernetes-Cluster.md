# Designing a Kubernetes Cluster

  - Take me to [Lecture](https://kodekloud.com/topic/design-a-kubernetes-cluster/)

  