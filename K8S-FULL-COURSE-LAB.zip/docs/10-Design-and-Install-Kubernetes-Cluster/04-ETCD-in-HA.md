# ETCD in HA

 - Take me to [Lecture](https://kodekloud.com/topic/etcd-in-ha/)