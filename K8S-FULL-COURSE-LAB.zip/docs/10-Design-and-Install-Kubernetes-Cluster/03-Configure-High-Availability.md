# Choosing a HA

  - Take me to [Lecture](https://kodekloud.com/topic/configure-high-availability/)