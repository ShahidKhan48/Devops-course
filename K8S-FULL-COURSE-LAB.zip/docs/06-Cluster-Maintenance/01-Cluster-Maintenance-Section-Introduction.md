# Cluster Maintenance Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/topic/cluster-maintenance-section-introduction-2/)
  
In this section, we will take a look at cluster maintenance
- Cluster Upgrade Process
- Operating System Upgrades
- Backup and Restore Methodologies
