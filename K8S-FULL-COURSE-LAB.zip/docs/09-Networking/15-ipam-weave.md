# IPAM weave

  - Take me to [Lecture](https://kodekloud.com/topic/ipam-weave/)

- IP Address Management in the Kubernetes Cluster

![net-3](../../images/net3.PNG)


- How weaveworks Manages IP addresses in the Kubernetes Cluster 

![net-4](../../images/net4.PNG)


## References Docs

- https://www.weave.works/docs/net/latest/kubernetes/kube-addon/
- https://kubernetes.io/docs/concepts/cluster-administration/networking/ 