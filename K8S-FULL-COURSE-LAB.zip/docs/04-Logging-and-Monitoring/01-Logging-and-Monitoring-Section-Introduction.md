# Logging and Monitoring Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/topic/logging-and-monitoring-section-introduction/)
  
In this section, we will take a look at the below
- Monitor Cluster Components
- Monitor Applications
- Monitor Cluster Components Logs
- Application Logs
